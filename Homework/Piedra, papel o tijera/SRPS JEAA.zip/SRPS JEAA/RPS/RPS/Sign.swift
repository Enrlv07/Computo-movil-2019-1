//
//  File.swift
//  RPS
//
//  Created by Macbook on 03/10/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import Foundation
//Se utiliza para la creación de señales aleatorias (en este caso)
import GameplayKit

let randomChoice = GKRandomDistribution(lowestValue: 0, highestValue: 2)

func randomSing() -> Sing{
    let sing = randomChoice.nextInt()
    if sing == 0{
        return .rock
    }
    else if sing == 1 {
        return .paper
    }
    else {
        return .scissors
    }
}

enum Sing {
    case rock, paper, scissors
    
    var emoji: String {
        switch self {
        case .rock:
            return "👊🏻"
        case .paper:
            return "🖐🏻"
        case .scissors:
            return "✌🏻"
        }
    }
    
    //Se realizan las posibles combinaciones entre los resultados, según el turno.
    func takeTurn(_ opponent: Sing) -> GameState{
        switch self {
        //Sí el turno es roca
            case .rock:
            switch opponent{
            case .rock:
                return GameState.draw //El resultado del oponente es roca, entonces hay empate
            case .paper:
                return GameState.lose //El resultado del oponente es papel, entonces perdió
            case .scissors:
                return GameState.win //El resultado del oponente es tijeras, entonces ganó
            }
        //Si el turno es papel
        case .paper:
            switch opponent{
            case .rock:
                return GameState.win
            case .paper:
                return GameState.draw
            case .scissors:
                return GameState.lose
            }
        //Si el turno es tijeras
        case .scissors:
            switch opponent{
            case .rock:
                return GameState.lose
            case .paper:
                return GameState.win
            case .scissors:
                return GameState.draw
            }
        }
    }
}
