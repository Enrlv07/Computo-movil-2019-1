//
//  File.swift
//  RPS
//
//  Created by Macbook on 03/10/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import Foundation


//Enum para los posibles resultados del juego
//star -> inicio
// win -> ganó
// lose -> perdió
//draw -> empate
enum GameState{
    case start, win, lose, draw
}
